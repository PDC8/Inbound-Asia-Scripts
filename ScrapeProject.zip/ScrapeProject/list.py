import requests
import json
from bs4 import BeautifulSoup

#some of the websites didn't fit the previous code
URL = "https://www.edinst.com/products/f980-software-photoluminescence-control-and-analysis/"
# getting response object
res = requests.get(URL)
# Initialize the object with the document
soup = BeautifulSoup(res.content, "html.parser")

lists = soup.find_all(class_='post')
output_data = {}
for list in lists:
    title = list.find(class_="post-title").text
    entry = list.find(class_="entry").text
    img = list.find(class_="img_wrapper").find('a')
    output_data[title] = entry
    output_data[title + " img"] = img['href']

f = open("output" + '39' + ".json", "a" )
f.write(json.dumps(output_data))
f.close()
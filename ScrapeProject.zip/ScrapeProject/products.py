import requests
import json
from bs4 import BeautifulSoup




# aux function
def tableFunction(lists):
    row_headers = []
    table_values = []
    for x in lists:
        for y in x.find(class_='row-1').find_all('th'):
            row_headers.append(y.text)
    

        for y in x.find_all('tr'):
            td_tags = y.find_all('td')
            td_val = [z.text for z in td_tags] 
            table_values.append(td_val)
    return [row_headers, table_values]






# main
website = open("Websites", 'r')
lines = website.readlines()
count = 3

for line in lines:
    if(line != ""):
        URL = line
    # URL = "https://www.edinst.com/products/rms1000-raman-microscope/"
    # getting response object
    res = requests.get(URL)

    # Initialize the object with the document
    soup = BeautifulSoup(res.content, "html.parser")
    try:

        page_title = soup.find(class_="page-title").text
        product_info = soup.find_all(class_= "product-section")
        output_data = {}
        output_data['Page Title'] = page_title

        try:
            intro = soup.find(class_="entry intro").text
            output_data['Introduction'] = intro
        except AttributeError:
            pass


        for info in product_info:
            subhead = info.find(class_="accordion-toggle").text
            tables = info.find_all(class_="tablepress")
            if(tables):
                output_data[subhead] = tableFunction(tables)
                for x in info.find_all('p'):
                    output_data[subhead].append(x.text)
            else:
                body = info.find(class_="entry").text
                output_data[subhead] = body

            output_data[subhead + ' img'] = []
            output_data[subhead + ' link'] = []

            image = info.find_all('img')
            for img in image:
                output_data[subhead + ' img'].append(img['src'])

            links = info.find_all('a')
            for link in links:
                output_data[subhead + ' link'].append(link['href'])
        f = open("output" + str(count) + ".json", "w" )
        f.write(json.dumps(output_data))
        f.close()
    except:
        f = open("output" + str(count) + ".json", "a" )
        f.write(json.dumps({'img': line}))
        f.close()
    count += 1
    # except AttributeError:
    #     f = open("output" + str(count) + ".json", "a" )
    #     f.write(json.dumps({'image_url': line}))
    #     f.close()
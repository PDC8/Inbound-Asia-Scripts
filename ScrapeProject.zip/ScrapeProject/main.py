import requests
import json
from bs4 import BeautifulSoup

#some of the websites didn't fit the previous code
URL = "https://www.edinst.com/products/"
# getting response object
res = requests.get(URL)
# Initialize the object with the document
soup = BeautifulSoup(res.content, "html.parser")

page_title = soup.find(class_="page-title").text
output_data = {}
output_data['Page Title'] = page_title

# intro = soup.find_all(class_="entry")[1].text
intro = soup.find(class_="entry").text
output_data['Entry'] = intro

lists = soup.find(class_='product-grid').find_all('li')
for list in lists:
    title = list.find(class_="content-wrapper").find('h3').text
    try:
        entry = list.find(class_="excerpt").text
        output_data[title] = entry
    except AttributeError:
        output_data[title] = ""
    link = list.find('a')['href']
    img = list.find('img')['src']
    output_data[title + ' img'] = img
    output_data[title + ' link'] = link

f = open("output" + '2' + ".json", "a" )
f.write(json.dumps(output_data))
f.close()
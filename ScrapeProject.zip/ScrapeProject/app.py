import requests
import json
from bs4 import BeautifulSoup


website = open("Websites", 'r')
lines = website.readlines()
count = 3
    
for line in lines:
    if(line != ""):
        URL = line
        
    # getting response object
    res = requests.get(URL)

    # Initialize the object with the document
    soup = BeautifulSoup(res.content, "html.parser")

    # Get the whole content tag
    try:
        content_body = soup.find(class_="content-area")
        content_text_list = list(content_body.strings)
        content_links = content_body.find_all('a')
        content_imgs = content_body.find_all('img')

        text = []
        for string in content_text_list:
            text.append(string)

        href = []
        for link in content_links:
            href.append(link['href'])

        src = []    
        for img in content_imgs:
            src.append(img['src'])


        output_data = {
            'url': line,
            'text': text,
            'href': href,
            'src': src
        }
        f = open("output" + str(count) + ".json", "a" )
        f.write(json.dumps(output_data))
        f.close()
    except AttributeError:
        f = open("output" + str(count) + ".json", "a" )
        f.write(json.dumps({'image_url': line}))
        f.close()
    count += 1















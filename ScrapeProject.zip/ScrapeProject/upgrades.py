import requests
import json
from bs4 import BeautifulSoup

#some of the websites didn't fit the previous code
URL = "https://www.edinst.com/products/lp980-upgrades/"
# getting response object
res = requests.get(URL)
# Initialize the object with the document
soup = BeautifulSoup(res.content, "html.parser")

output_data = {}

page_title = soup.find(class_="page-title").text
output_data['Page Title'] = page_title


intro = soup.find(class_="entry intro").text
output_data['Entry'] = intro


lists = soup.find_all(class_='entry')[1].find(class_="accordion")
title = lists.find_all(class_="accordion-title")
content = lists.find_all(class_="accordion-content")

count = 0
bound = len(title)

while count < bound:
    output_data[title[count].text] = content[count].text
    count += 1


f = open("output" + '103' + ".json", "a" )
f.write(json.dumps(output_data))
f.close()
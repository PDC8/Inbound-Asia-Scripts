import requests
import json
from bs4 import BeautifulSoup



def tableFunction(lists):
    row_headers = []
    table_values = []
    for x in lists:
        for y in x.find(class_='row-1').find_all('th'):
            row_headers.append(y.text)
    

        for y in x.find_all('tr'):
            td_tags = y.find_all('td')
            td_val = [z.text for z in td_tags] 
            table_values.append(td_val)
    return [row_headers, table_values]



#some of the websites didn't fit the previous code
URL = "https://www.edinst.com/products/fast-download/"
# getting response object
res = requests.get(URL)

# Initialize the object with the document
soup = BeautifulSoup(res.content, "html.parser")

page_title = soup.find(class_="page-title").text
output_data = {}
output_data['Page Title'] = page_title

# intro = soup.find_all(class_="entry")[1].text
intro = soup.find(class_="entry").text
output_data['Entry'] = intro

# tables = soup.find_all(class_="tablepress")
# output_data['Table'] = tableFunction(tables)




f = open("output" + '41' + ".json", "a" )
f.write(json.dumps(output_data))
f.close()

import requests
import csv
from bs4 import BeautifulSoup
import re




page = 1

with open('output.csv', mode='w') as csvfile:
    colname = ["會員編號", "統一編號", "負責人", "公司名稱", "公司地址", "公司電話", "公司傳真", "E-Mail", "網址", "工廠地址", "工廠電話", "工廠傳真", "主要營業項目", "產品許可證"]
    writer = csv.DictWriter(csvfile, fieldnames=colname)
    writer.writeheader()
    csvfile.close
    
while page < 22:
    URL = "https://www.tmbia.org.tw/member.php?&page=" + str(page)
    # getting response object
    res = requests.get(URL)

    # Initialize the object with the document
    soup = BeautifulSoup(res.content, "html.parser")

    company_list = soup.find_all(class_='member_List')[1:]

    for company in company_list:
        URL_detailed = "https://www.tmbia.org.tw/" + company.find('a')['href']
        res_detailed = requests.get(URL_detailed)
        soup_detailed = BeautifulSoup(res_detailed.content, "html.parser")
        contact_info = soup_detailed.find_all(class_="member_Table_List")
        title = soup_detailed.find(class_="member_Title").text
        list = []
        for contact in contact_info:
            list.append(contact.find(class_="member_Table_Td").text)

        with open('output.csv', mode='a') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(list)
        csvfile.close
    page += 1   